package Singleton_1;

public class SingletonJ {

	public static void main(String[] args)  {
		// TODO Auto-generated method stub

		
		Singleton[] mySingletonArray = new Singleton[5];//Array of objects
		
		for(int i = 0;i<5;i++){
			mySingletonArray[i] = Singleton.Instance();//get 5 singletons
			System.out.println(System.identityHashCode(mySingletonArray[i]));// check to see if their address is the same

		}
	}
}

class Singleton 
{
	
 public static Singleton Instance()  {
     if (_instance == null) {
         synchronized (Singleton.class) {
        	
        	 //----- Second lock -----
             if (_instance == null) {
                 _instance = new Singleton();
                 System.out.println("\nNew:  "+System.identityHashCode(_instance));// print if made new
             }
             
          }
     }
     return _instance;      
 }
 protected Singleton() {}
 private static Singleton _instance = null;
}
